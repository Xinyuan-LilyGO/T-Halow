
#ifndef _TXW4002A_803_DEVICE_H_
#define _TXW4002A_803_DEVICE_H_

extern void device_init(void);

#endif
