
#ifndef _HGIC_COMMON_H_
#define _HGIC_COMMON_H_

void cpu_loading_print(uint8 all);

void sdk_version(uint32 *sdk_ver, uint32 *svn_ver, uint32 *app_ver);

#endif

