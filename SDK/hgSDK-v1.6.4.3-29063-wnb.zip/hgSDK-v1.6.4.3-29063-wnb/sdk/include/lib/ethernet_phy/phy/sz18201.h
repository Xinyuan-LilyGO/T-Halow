#ifndef __SZ18201_H_
#define __SZ18201_H_

extern struct ethernet_phy_driver sz18201_driver;


#endif
