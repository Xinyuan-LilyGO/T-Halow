#ifndef __AUTO_PHY_H_
#define __AUTO_PHY_H_

extern struct ethernet_phy_driver auto_phy_driver;


#endif
